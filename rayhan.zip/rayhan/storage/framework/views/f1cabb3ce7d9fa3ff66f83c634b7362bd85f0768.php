<!DOCTYPE html>
<html>
<head>
<title>Rayhan </title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
<div class="jumbotron text-center">
  <h1><strong>Laravel 8 CRUD </strong></h1>
  <h4><b><ins>Created By:</ins></b></h4>
  
  <h4><b> Md. Rayhan Ahmed</b></h4> 
  <h4><b>ID: 181-115-013</b></h4>
  <h4><b>Students of CSE 44th(A) Batch</b></h4>
  <h5><strong>Metropolitan University, Sylhet</strong></h5>
</div>
  
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>
<div class="jumbotron text-center" style="margin-bottom:0">
	<div class="links">
		<a href="https://github.com/rayhan244">GitHub Link </a>
	</div>          
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\rayhan\resources\views/blogs/layout.blade.php ENDPATH**/ ?>