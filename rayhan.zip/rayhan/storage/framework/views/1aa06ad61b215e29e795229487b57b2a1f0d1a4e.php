<!DOCTYPE html>
<html>
<head>
<title>Rayhan </title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
<div class="jumbotron text-center">
  <h1>Laravel 8 CRUD </h1>
  <h4>Created By: Rayhan Ahmed</h4> 
  <h4>ID: 181-115-013</h4>
  <h4>From: Dept. of CSE 44th (A) </h4>
</div>
  
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>
<div class="jumbotron text-center" style="margin-bottom:0">
	<div class="links">
		<a href="https://github.com/rayhan244">GitHub Link </a>
	</div>          
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\Rayhan\resources\views/blogs/layout.blade.php ENDPATH**/ ?>